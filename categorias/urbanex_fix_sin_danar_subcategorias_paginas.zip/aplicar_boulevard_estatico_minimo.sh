#!/usr/bin/env bash
set -e
if [ -f boulevard.html ]; then
python3 - <<'PYFIX'
from pathlib import Path
import re
p=Path('boulevard.html')
s=p.read_text(encoding='utf-8')
patch="""
/* === URBANEX BOULEVARD ESTATICO MINIMO === */
html, body { height:100%; overflow:hidden; }
.dashboard-container { height:calc(100vh - 24px) !important; min-height:0 !important; overflow:hidden !important; }
.header-top { flex-shrink:0 !important; z-index:90 !important; }
.pie-pagina { position:fixed !important; left:0 !important; right:0 !important; bottom:0 !important; height:24px !important; z-index:999 !important; }
.main-boulevard { min-height:0 !important; overflow:hidden !important; }
.aside-categories, .aside-showcase-list, .shops-scroll-area, .categories-list { min-height:0 !important; }
@media(max-width:720px){
  .dashboard-container { height:calc(100svh - 24px) !important; overflow:hidden !important; }
  .main-boulevard { overflow:hidden !important; background-position:center bottom !important; }
}
/* === FIN URBANEX BOULEVARD ESTATICO MINIMO === */
"""
s=re.sub(r'/\* === URBANEX BOULEVARD ESTATICO MINIMO === \*/.*?/\* === FIN URBANEX BOULEVARD ESTATICO MINIMO === \*/','',s,flags=re.S)
s=s.replace('</style>',patch+'
</style>',1)
p.write_text(s,encoding='utf-8')
PYFIX
fi
